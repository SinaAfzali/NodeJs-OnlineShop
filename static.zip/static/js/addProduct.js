import React, { useState } from 'react';
import './addProduct.css'; // Import CSS file for styling

function AddProduct({ onAddProduct, onBack }) {
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    description: '',
    productNumber: '',
    image: null, // Initialize image as null
    filter: '',
    discount: '' // New field for discount
  });

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'file' ? e.target.files[0] : value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddProduct(formData);
    // You can also reset the form here if needed
  };

  return (
    <div className="add-product-container">
      <div className="background"></div>
      <div className="info-message">
        <p>فروشنده عزیز لطفا از نماد مناسب برای فاصله استفاده کنید</p>
      </div>
      <h2>افزودن محصول</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>نام<span className="required">*</span>:</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>قیمت<span className="required">*</span>:</label>
          <input type="text" name="price" value={formData.price} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>توضیحات:</label>
          <textarea name="description" value={formData.description} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label>تعداد محصول:</label>
          <input type="text" name="productNumber" value={formData.productNumber} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label>عکس محصول:</label>
          <input type="file" name="image" onChange={handleChange} accept="image/*" />
        </div>
        <div className="form-group">
          <label>دسته بندی<span className="required">*</span>:</label>
          <select name="filter" value={formData.filter} onChange={handleChange} required>
            <option value="">انتخاب کنید</option>
            <option value="option1">موبایل</option>
            <option value="option2">لوازم تحریر</option>
            <option value="option3">کالا های سوپرمارکتی</option>
            <option value="option4">اسباب بازی</option>
            <option value="option5">آرایشی بهداشتی</option>
            <option value="option6">مد و پوشاک</option>
            <option value="option7">ورزش و سفر</option>
            <option value="option8">ابزار آلات و تجهیزات</option>
            <option value="option9">تجهیزات پزشکی و سلامت</option>
          </select>
        </div>
        <div className="form-group">
          <label>(اختیاری)تخفیف اولیه فروش:</label> {/* New field for discount */}
          <input type="text" name="discount" value={formData.discount} onChange={handleChange} />
        </div>
        
        <div className="button-group">
          <button type="button" onClick={onBack} className="red-button">Back</button>
          <button type="submit">Confirm</button>
        </div>

      </form>
    </div>
  );
}

export default AddProduct;
